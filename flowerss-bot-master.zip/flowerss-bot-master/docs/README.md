# flowerss bot

> 一个支持应用内即时预览的 Telegram RSS Bot。

## Features

- 常见的 RSS Bot 该有的功能；
- 支持 Telegram 应用内即时预览；
- 支持为 Group 和 Channel 订阅 RSS 消息；
- 丰富的订阅设置。

<img src="https://github.com/rssflow/img/raw/master/images/rssflow_demo.gif" width = "300"/>



## 问题反馈

如果你在使用过程中遇到问题，请在 GitHub 提交 Issue，并附上 Bot 日志。