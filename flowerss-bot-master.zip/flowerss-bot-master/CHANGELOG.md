# Changelog

## [Unreleased] 2019-10-29

### Added
- source update fetch control by `/set` command (usually used when source updating paused by reached 100 error when 
getting update data)
- export feeds

### Changed
- merge `/set` command's response message template to a function for more struct

